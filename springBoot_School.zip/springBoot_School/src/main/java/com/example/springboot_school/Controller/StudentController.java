package com.example.springboot_school.Controller;

import com.example.springboot_school.ApiResponse;
import com.example.springboot_school.Model.Student;
import com.example.springboot_school.Service.Service;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/student")
@RequiredArgsConstructor
public class StudentController {

    private final Service studentService;

    @GetMapping("/get")
    public ResponseEntity getStudent(){
        ArrayList<Student> student = studentService.getStudent();
        return ResponseEntity.status(200).body(student);
    }

    @PostMapping("/add")
    public ResponseEntity addStudent(@RequestBody @Valid Student student , Errors errors){
        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        studentService.addStudent(student);
        return ResponseEntity.status(200).body(new ApiResponse("student added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateStudent(@PathVariable Integer id , @RequestBody @Valid Student student , Errors errors){
        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        if(studentService.updateStudent(id, student))
            return ResponseEntity.status(201).body("student Updated!");
        return ResponseEntity.status(400).body("wrong student");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteStudent(@PathVariable Integer id ){
        if(studentService.deleteStudent(id))
            return ResponseEntity.status(201).body("student deleted            !");
        return ResponseEntity.status(400).body("wrong student!");
    }
/
    @GetMapping("/get/{id}")
    public ResponseEntity getStudentByID(@PathVariable int id)
    {
        Student student= studentService.getStudentById(id);
        if(student != null)
            return ResponseEntity.status(201).body(student);
        return ResponseEntity.status(400).body("STUDENT NOT FOUND!!");
    }

    @GetMapping("/get/by/name")
    public ResponseEntity getStudentByName(@RequestBody String name)
    {
        Student student = studentService.getStudentsByName(name);
        if(student != null)
            return ResponseEntity.status(201).body(student);
        return ResponseEntity.status(400).body("STUDENT NOT FOUND!!");
    }

    @GetMapping("/get/by/major")
    public ResponseEntity getMajorStudents(@RequestBody String major)
    {
        ArrayList<Student> majorStudents = studentService.getMajorStudents(major);
        if(!majorStudents.isEmpty())
            return ResponseEntity.status(201).body(majorStudents);
        return ResponseEntity.status(400).body("No Students in "+major);
    }

    @GetMapping("/get/by/age")
    public ResponseEntity getAgeStudents(@RequestBody Integer age)
    {
        ArrayList<Student> ageStudents = studentService.getAgeStudents(age);
        if(!ageStudents.isEmpty())
            return ResponseEntity.status(201).body(ageStudents);
        return ResponseEntity.status(400).body("No Students are "+age+" or older");
    }



}
