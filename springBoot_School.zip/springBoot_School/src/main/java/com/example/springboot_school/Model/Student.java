package com.example.springboot_school.Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Student {

    @NotNull(message = "ID can't be empty")
    private Integer id;

    @NotEmpty(message = "Name can't be empty")
    private String name;

    @NotNull(message = "Age can't be empty")
    private int age;

    @NotEmpty(message = "Major can't be empty")
    @Pattern(regexp = "(CS | MATH | Engineer)", message = "choose one of these Majors (CS, MATH, Engineer)")
    private String major;


}
