package com.example.springboot_school.Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Teacher {

    @NotNull(message = "ID can't be empty")
    private Integer id;

    @NotEmpty(message = "Name can't be empty")
    private String name;

    @NotNull (message = "Salary can't be empty")
    private int salary;

}
